./rcS/S10dgs_xal
./rcS/S20dgs_drv
./rcS/S30dgs_sdk
./rcS/S40dgs_app
