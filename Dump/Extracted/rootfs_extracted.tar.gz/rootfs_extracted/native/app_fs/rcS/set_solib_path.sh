BIN="${CWD}/bin"

export LD_LIBRARY_PATH=${BIN}
