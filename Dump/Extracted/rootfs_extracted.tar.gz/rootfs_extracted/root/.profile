export PATH=$PATH:/usr/local/sbin:/tmp/tools:/etc/ath
alias ll="ls -al"

